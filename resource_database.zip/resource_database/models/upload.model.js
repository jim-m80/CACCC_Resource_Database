const mongoose = require('mongoose');

// schema of the database
var uploadSchema = new mongoose.Schema({
	fileName: String,
	data: Buffer
});

//passed the schema to a mongoose model
mongoose.model('upload',uploadSchema);
